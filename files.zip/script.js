/**
 * TYAGI FASHION – Main JavaScript
 * Author  : Tyagi Fashion Dev Team
 * Version : 1.0.0
 *
 * Sections:
 *  1. Product Data
 *  2. Loader
 *  3. Navbar (sticky + mobile menu + search)
 *  4. Hero Slider
 *  5. Product Cards (render + filter)
 *  6. Cart (state + sidebar + toast)
 *  7. Wishlist
 *  8. Countdown Timer
 *  9. Scroll Reveal Animations
 * 10. Back To Top
 * 11. Newsletter Form
 * 12. Smooth Active Nav Link
 */

'use strict';

/* ============================================================
   1. PRODUCT DATA
   ============================================================ */
const products = [
  {
    id: 1,
    name: 'Structured Wool Blazer',
    category: 'men',
    categoryLabel: "Men's Wear",
    price: 7999,
    oldPrice: 14500,
    rating: 4.8,
    reviews: 124,
    badge: 'Sale',
    badgeClass: 'badge-sale',
    image: 'https://images.unsplash.com/photo-1594938298603-c8148c4b4de4?w=600&q=80',
  },
  {
    id: 2,
    name: 'Silk Midi Dress',
    category: 'women',
    categoryLabel: "Women's Wear",
    price: 5499,
    oldPrice: 10999,
    rating: 4.9,
    reviews: 89,
    badge: 'New',
    badgeClass: 'badge-new',
    image: 'https://images.unsplash.com/photo-1495385794356-15371f348c31?w=600&q=80',
  },
  {
    id: 3,
    name: 'Premium Sneakers',
    category: 'shoes',
    categoryLabel: 'Shoes',
    price: 4299,
    oldPrice: 7999,
    rating: 4.7,
    reviews: 211,
    badge: 'Hot',
    badgeClass: '',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80',
  },
  {
    id: 4,
    name: 'Linen Summer Shirt',
    category: 'men',
    categoryLabel: "Men's Wear",
    price: 1899,
    oldPrice: 3499,
    rating: 4.6,
    reviews: 67,
    badge: 'Sale',
    badgeClass: 'badge-sale',
    image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600&q=80',
  },
  {
    id: 5,
    name: 'Luxury Leather Tote',
    category: 'accessories',
    categoryLabel: 'Accessories',
    price: 6999,
    oldPrice: 12000,
    rating: 5.0,
    reviews: 43,
    badge: 'New',
    badgeClass: 'badge-new',
    image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=600&q=80',
  },
  {
    id: 6,
    name: 'Floral Wrap Dress',
    category: 'women',
    categoryLabel: "Women's Wear",
    price: 3299,
    oldPrice: 5999,
    rating: 4.8,
    reviews: 156,
    badge: '',
    badgeClass: '',
    image: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=600&q=80',
  },
  {
    id: 7,
    name: 'Classic Aviator Jacket',
    category: 'men',
    categoryLabel: "Men's Wear",
    price: 8999,
    oldPrice: 16999,
    rating: 4.9,
    reviews: 78,
    badge: 'Sale',
    badgeClass: 'badge-sale',
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600&q=80',
  },
  {
    id: 8,
    name: 'Gold Chain Necklace',
    category: 'accessories',
    categoryLabel: 'Accessories',
    price: 2499,
    oldPrice: 4500,
    rating: 4.7,
    reviews: 92,
    badge: 'New',
    badgeClass: 'badge-new',
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=600&q=80',
  },
];

/* ============================================================
   2. LOADER
   ============================================================ */
const loader = document.getElementById('loader');

window.addEventListener('load', () => {
  setTimeout(() => {
    loader.classList.add('hidden');
    document.body.style.overflow = '';
  }, 2200);
});

// Prevent scroll during load
document.body.style.overflow = 'hidden';

/* ============================================================
   3. NAVBAR
   ============================================================ */
const navbar     = document.getElementById('navbar');
const navToggle  = document.getElementById('navToggle');
const navLinks   = document.getElementById('navLinks');
const searchToggle = document.getElementById('searchToggle');
const searchBar    = document.getElementById('searchBar');
const searchClose  = document.getElementById('searchClose');

// Sticky scroll
window.addEventListener('scroll', () => {
  if (window.scrollY > 30) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
}, { passive: true });

// Mobile menu
navToggle.addEventListener('click', () => {
  const open = navToggle.classList.toggle('open');
  navLinks.classList.toggle('open', open);
  navToggle.setAttribute('aria-expanded', open);
});

// Close mobile menu on link click
navLinks.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', () => {
    navToggle.classList.remove('open');
    navLinks.classList.remove('open');
  });
});

// Search toggle
searchToggle.addEventListener('click', () => {
  const open = searchBar.classList.toggle('open');
  if (open) {
    document.getElementById('searchInput').focus();
  }
});
searchClose.addEventListener('click', () => searchBar.classList.remove('open'));

// Close search on Escape
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') searchBar.classList.remove('open');
});

/* ============================================================
   4. HERO SLIDER
   ============================================================ */
const heroSlides = document.querySelectorAll('.hero-slide');
const heroDots   = document.querySelectorAll('.hero-dot');
const heroPrev   = document.querySelector('.hero-prev');
const heroNext   = document.querySelector('.hero-next');
let currentSlide = 0;
let sliderInterval;

function goToSlide(index) {
  heroSlides[currentSlide].classList.remove('active');
  heroDots[currentSlide].classList.remove('active');
  currentSlide = (index + heroSlides.length) % heroSlides.length;
  heroSlides[currentSlide].classList.add('active');
  heroDots[currentSlide].classList.add('active');
}

function startSlider() {
  sliderInterval = setInterval(() => goToSlide(currentSlide + 1), 5500);
}

heroNext.addEventListener('click', () => { goToSlide(currentSlide + 1); resetSlider(); });
heroPrev.addEventListener('click', () => { goToSlide(currentSlide - 1); resetSlider(); });
heroDots.forEach(dot => {
  dot.addEventListener('click', () => { goToSlide(+dot.dataset.index); resetSlider(); });
});

function resetSlider() {
  clearInterval(sliderInterval);
  startSlider();
}
startSlider();

/* ============================================================
   5. PRODUCT CARDS
   ============================================================ */

/**
 * Generates star HTML for a given rating.
 * @param {number} rating - Rating between 0 and 5
 * @returns {string} HTML string of star icons
 */
function renderStars(rating) {
  const full  = Math.floor(rating);
  const half  = rating % 1 >= 0.5 ? 1 : 0;
  const empty = 5 - full - half;
  return (
    '<i class="ri-star-fill"></i>'.repeat(full) +
    (half ? '<i class="ri-star-half-fill"></i>' : '') +
    '<i class="ri-star-line"></i>'.repeat(empty)
  );
}

/**
 * Renders a product card HTML string.
 * @param {Object} product
 * @returns {string} HTML string
 */
function renderProductCard(product) {
  const discount = product.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : 0;

  return `
    <div class="product-card reveal" data-category="${product.category}">
      <div class="product-img-wrap">
        <img src="${product.image}" alt="${product.name}" loading="lazy" />
        ${product.badge ? `<span class="product-badge ${product.badgeClass}">${product.badge}</span>` : ''}
        <div class="product-actions">
          <button
            class="product-action-btn wishlist-btn"
            data-id="${product.id}"
            aria-label="Add to wishlist"
            title="Add to Wishlist"
          ><i class="ri-heart-line"></i></button>
          <button
            class="product-action-btn"
            aria-label="Quick view"
            title="Quick View"
            onclick="showToast('Quick view coming soon!')"
          ><i class="ri-eye-line"></i></button>
        </div>
      </div>
      <div class="product-body">
        <p class="product-cat">${product.categoryLabel}</p>
        <h3 class="product-name">${product.name}</h3>
        <div class="product-rating">
          ${renderStars(product.rating)}
          <span>(${product.reviews})</span>
        </div>
        <div class="product-price">
          <span class="price-current">₹${product.price.toLocaleString('en-IN')}</span>
          ${product.oldPrice ? `<span class="price-old">₹${product.oldPrice.toLocaleString('en-IN')}</span>` : ''}
          ${discount > 0 ? `<span class="price-off">${discount}% OFF</span>` : ''}
        </div>
      </div>
      <div class="product-footer">
        <button
          class="btn-add-cart"
          data-id="${product.id}"
          data-name="${product.name}"
          data-price="${product.price}"
          data-image="${product.image}"
          aria-label="Add ${product.name} to cart"
        >Add to Cart</button>
      </div>
    </div>
  `;
}

const productsGrid = document.getElementById('productsGrid');

function renderProducts(filter = 'all') {
  const filtered = filter === 'all'
    ? products
    : products.filter(p => p.category === filter);

  productsGrid.innerHTML = filtered.map(renderProductCard).join('');

  // Re-attach event listeners for dynamically rendered elements
  attachCartListeners();
  attachWishlistListeners();

  // Trigger reveal for newly added cards
  observeReveal();
}

// Filter tabs
document.querySelectorAll('.filter-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelector('.filter-tab.active').classList.remove('active');
    tab.classList.add('active');
    renderProducts(tab.dataset.filter);
  });
});

// Initial render
renderProducts();

/* ============================================================
   6. CART
   ============================================================ */
let cart = JSON.parse(localStorage.getItem('tf_cart') || '[]');

const cartBtn       = document.querySelector('.cart-btn');
const cartSidebar   = document.getElementById('cartSidebar');
const cartOverlay   = document.getElementById('cartOverlay');
const cartClose     = document.getElementById('cartClose');
const cartContinue  = document.getElementById('cartContinue');
const cartShopLink  = document.getElementById('cartShopLink');

function saveCart() {
  localStorage.setItem('tf_cart', JSON.stringify(cart));
}

function updateCartCount() {
  const count = cart.reduce((sum, item) => sum + item.qty, 0);
  document.getElementById('cartCount').textContent = count;
  document.getElementById('cartSidebarCount').textContent = `(${count})`;
}

function updateCartUI() {
  const cartItemsEl = document.getElementById('cartItems');
  const cartFooter  = document.getElementById('cartFooter');
  const cartTotal   = document.getElementById('cartTotal');

  if (cart.length === 0) {
    cartItemsEl.innerHTML = `
      <div class="cart-empty">
        <i class="ri-shopping-bag-2-line"></i>
        <p>Your bag is empty</p>
        <a href="#shop" class="btn btn-gold" id="cartShopLink">Start Shopping</a>
      </div>`;
    cartFooter.style.display = 'none';

    // Re-attach close-on-click
    document.getElementById('cartShopLink')?.addEventListener('click', closeCart);
  } else {
    let total = 0;
    cartItemsEl.innerHTML = cart.map(item => {
      total += item.price * item.qty;
      return `
        <div class="cart-item">
          <img src="${item.image}" alt="${item.name}" />
          <div class="cart-item-info">
            <h4>${item.name}</h4>
            <p>Qty: ${item.qty}</p>
            <strong>₹${(item.price * item.qty).toLocaleString('en-IN')}</strong>
          </div>
          <button class="cart-item-remove" data-id="${item.id}" aria-label="Remove ${item.name}">
            <i class="ri-close-line"></i>
          </button>
        </div>`;
    }).join('');

    cartFooter.style.display = 'flex';
    cartTotal.textContent = `₹${total.toLocaleString('en-IN')}`;

    // Remove item listeners
    document.querySelectorAll('.cart-item-remove').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = +btn.dataset.id;
        cart = cart.filter(item => item.id !== id);
        saveCart();
        updateCartCount();
        updateCartUI();
      });
    });
  }
}

function addToCart(id, name, price, image) {
  const existing = cart.find(item => item.id === id);
  if (existing) {
    existing.qty++;
  } else {
    cart.push({ id, name, price: +price, image, qty: 1 });
  }
  saveCart();
  updateCartCount();
  updateCartUI();
  showToast(`"${name}" added to bag`);
  openCart();
}

function openCart() {
  cartSidebar.classList.add('open');
  cartOverlay.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeCart() {
  cartSidebar.classList.remove('open');
  cartOverlay.classList.remove('open');
  document.body.style.overflow = '';
}

cartBtn.addEventListener('click', openCart);
cartClose.addEventListener('click', closeCart);
cartOverlay.addEventListener('click', closeCart);
cartContinue?.addEventListener('click', closeCart);

function attachCartListeners() {
  document.querySelectorAll('.btn-add-cart').forEach(btn => {
    btn.addEventListener('click', () => {
      addToCart(
        +btn.dataset.id,
        btn.dataset.name,
        btn.dataset.price,
        btn.dataset.image
      );
    });
  });
}

// Initialize
updateCartCount();
updateCartUI();

/* ============================================================
   7. WISHLIST
   ============================================================ */
let wishlist = JSON.parse(localStorage.getItem('tf_wishlist') || '[]');

function toggleWishlist(btn, id) {
  const idx = wishlist.indexOf(id);
  const icon = btn.querySelector('i');
  if (idx === -1) {
    wishlist.push(id);
    icon.className = 'ri-heart-fill';
    btn.classList.add('wishlist-active');
    showToast('Added to wishlist ♥');
  } else {
    wishlist.splice(idx, 1);
    icon.className = 'ri-heart-line';
    btn.classList.remove('wishlist-active');
    showToast('Removed from wishlist');
  }
  localStorage.setItem('tf_wishlist', JSON.stringify(wishlist));
}

function attachWishlistListeners() {
  document.querySelectorAll('.wishlist-btn').forEach(btn => {
    const id = +btn.dataset.id;
    const icon = btn.querySelector('i');

    // Restore state from storage
    if (wishlist.includes(id)) {
      icon.className = 'ri-heart-fill';
      btn.classList.add('wishlist-active');
    }

    btn.addEventListener('click', () => toggleWishlist(btn, id));
  });
}

/* ============================================================
   8. COUNTDOWN TIMER
   ============================================================ */
(function initCountdown() {
  // Set sale end: 3 days from page load (persisted in sessionStorage)
  const STORAGE_KEY = 'tf_sale_end';
  let endTime = sessionStorage.getItem(STORAGE_KEY);
  if (!endTime) {
    endTime = Date.now() + 3 * 24 * 60 * 60 * 1000;
    sessionStorage.setItem(STORAGE_KEY, endTime);
  }
  endTime = +endTime;

  const cdDays  = document.getElementById('cd-days');
  const cdHours = document.getElementById('cd-hours');
  const cdMins  = document.getElementById('cd-mins');
  const cdSecs  = document.getElementById('cd-secs');

  function pad(n) { return String(n).padStart(2, '0'); }

  function tick() {
    const diff = endTime - Date.now();
    if (diff <= 0) {
      cdDays.textContent = cdHours.textContent = cdMins.textContent = cdSecs.textContent = '00';
      return;
    }
    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff % 86400000) / 3600000);
    const m = Math.floor((diff % 3600000)  / 60000);
    const s = Math.floor((diff % 60000)    / 1000);
    cdDays.textContent  = pad(d);
    cdHours.textContent = pad(h);
    cdMins.textContent  = pad(m);
    cdSecs.textContent  = pad(s);
  }

  tick();
  setInterval(tick, 1000);
})();

/* ============================================================
   9. SCROLL REVEAL ANIMATIONS
   ============================================================ */
let revealObserver;

function observeReveal() {
  const elements = document.querySelectorAll('.reveal:not(.visible)');

  if (!('IntersectionObserver' in window)) {
    elements.forEach(el => el.classList.add('visible'));
    return;
  }

  if (revealObserver) revealObserver.disconnect();

  revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const delay = entry.target.dataset.delay || 0;
        setTimeout(() => {
          entry.target.classList.add('visible');
        }, +delay);
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  elements.forEach(el => revealObserver.observe(el));
}

// Initial observation after DOM ready
document.addEventListener('DOMContentLoaded', observeReveal);
// Also run on window load (catches images)
window.addEventListener('load', observeReveal);

/* ============================================================
   10. BACK TO TOP
   ============================================================ */
const backToTop = document.getElementById('backToTop');

window.addEventListener('scroll', () => {
  backToTop.classList.toggle('visible', window.scrollY > 400);
}, { passive: true });

backToTop.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

/* ============================================================
   11. NEWSLETTER FORM
   ============================================================ */
const newsletterForm  = document.getElementById('newsletterForm');
const newsletterEmail = document.getElementById('newsletterEmail');

newsletterForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const email = newsletterEmail.value.trim();
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    showToast('Please enter a valid email address');
    newsletterEmail.focus();
    return;
  }
  showToast('🎉 You\'re in! Enjoy 10% off your first order.');
  newsletterEmail.value = '';
});

/* ============================================================
   12. TOAST NOTIFICATION
   ============================================================ */
let toastTimeout;

/**
 * Shows a toast message for 3 seconds.
 * @param {string} message
 */
function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove('show'), 3000);
}

// Expose to inline HTML handlers
window.showToast = showToast;

/* ============================================================
   13. SMOOTH ACTIVE NAV LINK (Intersection Observer)
   ============================================================ */
const sections  = document.querySelectorAll('section[id], footer[id]');
const navItems  = document.querySelectorAll('.nav-link');

const sectionObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const id = entry.target.id;
      navItems.forEach(link => {
        link.classList.toggle('active', link.getAttribute('href') === `#${id}`);
      });
    }
  });
}, { threshold: 0.3 });

sections.forEach(section => sectionObserver.observe(section));

/* ============================================================
   14. ANNOUNCEMENT STRIP – PAUSE ON HOVER
   ============================================================ */
const strip = document.querySelector('.strip-track');
if (strip) {
  strip.addEventListener('mouseenter', () => strip.style.animationPlayState = 'paused');
  strip.addEventListener('mouseleave', () => strip.style.animationPlayState = 'running');
}

/* ============================================================
   15. LAZY IMAGE LOADING FALLBACK
   ============================================================ */
document.querySelectorAll('img[loading="lazy"]').forEach(img => {
  img.addEventListener('error', () => {
    img.src = 'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=400&q=60';
    img.alt = 'Image unavailable';
  });
});
